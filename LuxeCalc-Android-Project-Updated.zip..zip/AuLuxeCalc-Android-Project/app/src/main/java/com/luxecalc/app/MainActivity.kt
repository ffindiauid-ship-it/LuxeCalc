package com.luxecalc.app

import android.os.Bundle
import android.content.Context
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.*

private val Accent = Color(0xFFFF9F0A)
private val DarkBg = Color(0xFF090A0C)
private val DarkKey = Color(0xFF25272B)
private val DarkUtility = Color(0xFFA5A7AB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 10, 12)
        window.navigationBarColor = android.graphics.Color.rgb(9, 10, 12)
        setContent { LuxeCalcApp() }
    }
}

@Composable
fun LuxeCalcApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("luxecalc", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("0") }
    var history by remember { mutableStateOf(prefs.getStringSet("history", emptySet())?.toList()?.reversed() ?: emptyList()) }
    var showHistory by remember { mutableStateOf(false) }
    var scientific by remember { mutableStateOf(false) }
    var justEvaluated by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }
    val view = LocalView.current
    val clipboard = LocalClipboardManager.current

    val bg = if (dark) DarkBg else Color(0xFFF4F4F6)
    val primaryText = if (dark) Color.White else Color(0xFF17181A)
    val keyBg = if (dark) DarkKey else Color(0xFFE4E5E8)
    val utilityBg = if (dark) DarkUtility else Color(0xFFD0D2D6)
    val utilityText = if (dark) Color.Black else Color(0xFF25262A)

    fun tap(key: String) {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        when (key) {
            "AC" -> { expression = ""; result = "0"; error = false; justEvaluated = false }
            "⌫" -> { if (expression.isNotEmpty()) expression = expression.dropLast(1); error = false }
            "=" -> {
                if (expression.isNotBlank()) {
                    try {
                        val value = ExpressionParser(expression).parse()
                        result = formatNumber(value)
                        val entry = "$expression = $result"
                        history = (listOf(entry) + history).distinct().take(100)
                        prefs.edit().putStringSet("history", history.toSet()).apply()
                        expression = result
                        justEvaluated = true
                        error = false
                    } catch (_: Exception) {
                        result = "Error"
                        error = true
                    }
                }
            }
            "±" -> {
                if (expression.isNotBlank()) {
                    expression = if (expression.startsWith("-")) expression.drop(1) else "-($expression)"
                }
            }
            "%" -> {
                if (expression.isNotBlank()) expression += "%"
            }
            else -> {
                if (justEvaluated && (key.firstOrNull()?.isDigit() == true || key == "." || key == "π")) expression = ""
                expression += key
                justEvaluated = false
                error = false
                try { result = formatNumber(ExpressionParser(expression).parse()) } catch (_: Exception) { }
            }
        }
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(background = bg, surface = bg, onBackground = primaryText, onSurface = primaryText) else lightColorScheme(background = bg, surface = bg, onBackground = primaryText, onSurface = primaryText)) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            if (showHistory) {
                Column(Modifier.fillMaxSize().padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("History", color = primaryText, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { showHistory = false }) { Icon(Icons.Default.Close, null, tint = primaryText) }
                    }
                    if (history.isEmpty()) Text("Your calculations will appear here.", color = primaryText.copy(alpha = .55f), modifier = Modifier.padding(top = 28.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(history) { item ->
                            Text(item, color = primaryText, fontSize = 20.sp, modifier = Modifier.fillMaxWidth().clickable {
                                expression = item.substringAfter("= ").trim()
                                showHistory = false
                            }.padding(vertical = 16.dp), textAlign = TextAlign.End)
                            HorizontalDivider(color = primaryText.copy(alpha = .10f))
                        }
                    }
                    TextButton(onClick = {
                        history = emptyList()
                        prefs.edit().remove("history").apply()
                    }) { Text("Clear history", color = Accent) }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("LUXECALC", color = primaryText.copy(alpha = .58f), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showHistory = true }) { Icon(Icons.Default.History, "History", tint = primaryText) }
                            TextButton(onClick = { scientific = !scientific }) { Text(if (scientific) "BASIC" else "SCI", color = Accent, fontWeight = FontWeight.Bold) }
                            TextButton(onClick = {
                                dark = !dark
                                prefs.edit().putBoolean("dark", dark).apply()
                            }) { Text(if (dark) "☼" else "☾", color = primaryText, fontSize = 20.sp) }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(expression.ifBlank { " " }, color = primaryText.copy(alpha = .55f), fontSize = 25.sp, textAlign = TextAlign.End, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                        IconButton(onClick = { clipboard.setText(androidx.compose.ui.text.AnnotatedString(result)) }) {
                            Icon(Icons.Default.ContentCopy, "Copy result", tint = primaryText.copy(alpha = .45f))
                        }
                        Text(if (error) "Error" else result, color = primaryText, fontSize = 54.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.End, maxLines = 1, softWrap = false, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(22.dp))
                    val basicRows = listOf(
                        listOf("AC", "±", "%", "÷"),
                        listOf("7", "8", "9", "×"),
                        listOf("4", "5", "6", "−"),
                        listOf("1", "2", "3", "+"),
                        listOf("⌫", "0", ".", "=")
                    )
                    val sciRows = listOf(
                        listOf("sin(", "cos(", "tan(", "√("),
                        listOf("ln(", "log(", "π", "^"),
                        listOf("(", ")", "e", "÷")
                    )
                    if (scientific) {
                        sciRows.forEach { row -> KeyRow(row, keyBg, primaryText, Accent, utilityBg, utilityText, ::tap) }
                    }
                    basicRows.forEachIndexed { index, row ->
                        KeyRow(row, keyBg, primaryText, Accent, utilityBg, utilityText, ::tap, index == 0)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Designed for everyday calculations", color = primaryText.copy(alpha = .30f), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp))
                }
            }
        }
    }
}

@Composable
private fun KeyRow(
    keys: List<String>, keyBg: Color, text: Color, accent: Color,
    utilityBg: Color, utilityText: Color, onTap: (String) -> Unit, utilityFirstRow: Boolean = false
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        keys.forEach { key ->
            val isOperator = key in listOf("÷", "×", "−", "+", "=","^")
            val isUtility = key in listOf("AC", "±", "%", "⌫")
            val background = when {
                isOperator -> accent
                isUtility -> utilityBg
                else -> keyBg
            }
            val foreground = when {
                isOperator -> Color.White
                isUtility -> utilityText
                else -> text
            }
            Box(
                modifier = Modifier.weight(1f).padding(vertical = 5.dp).aspectRatio(1f)
                    .clip(CircleShape).background(background).clickable { onTap(key) },
                contentAlignment = Alignment.Center
            ) {
                Text(key, color = foreground, fontSize = if (key.length > 2) 17.sp else 25.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
        }
    }
}

private fun formatNumber(value: Double): String {
    if (!value.isFinite()) throw ArithmeticException("Non-finite result")
    if (abs(value) < 1e-12) return "0"
    val bd = BigDecimal.valueOf(value).round(MathContext(12, RoundingMode.HALF_UP)).stripTrailingZeros()
    return bd.toPlainString()
}

private class ExpressionParser(private val input: String) {
    private var pos = 0
    private val s = input.replace("×", "*").replace("÷", "/").replace("−", "-").replace("π", "pi").replace("√", "sqrt")
    fun parse(): Double {
        val value = expression()
        skip()
        if (pos != s.length) throw IllegalArgumentException("Unexpected input")
        if (!value.isFinite()) throw ArithmeticException("Invalid result")
        return value
    }
    private fun skip() { while (pos < s.length && s[pos].isWhitespace()) pos++ }
    private fun eat(c: Char): Boolean { skip(); if (pos < s.length && s[pos] == c) { pos++; return true }; return false }
    private fun expression(): Double {
        var x = term()
        while (true) { x = when { eat('+') -> x + term(); eat('-') -> x - term(); else -> return x } }
    }
    private fun term(): Double {
        var x = power()
        while (true) {
            x = when {
                eat('*') -> x * power()
                eat('/') -> { val d = power(); if (d == 0.0) throw ArithmeticException("Division by zero"); x / d }
                else -> return x
            }
        }
    }
    private fun power(): Double {
        var x = unary()
        if (eat('^')) x = x.pow(power())
        return x
    }
    private fun unary(): Double {
        if (eat('+')) return unary()
        if (eat('-')) return -unary()
        return postfix()
    }
    private fun postfix(): Double {
        var x = atom()
        while (eat('%')) x /= 100.0
        return x
    }
    private fun atom(): Double {
        skip()
        if (eat('(')) { val x = expression(); if (!eat(')')) throw IllegalArgumentException("Missing )"); return x }
        val start = pos
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        if (pos > start) return s.substring(start, pos).toDouble()
        val nameStart = pos
        while (pos < s.length && s[pos].isLetter()) pos++
        if (pos > nameStart) {
            val name = s.substring(nameStart, pos)
            return when (name) {
                "pi" -> Math.PI
                "e" -> Math.E
                "sqrt", "sin", "cos", "tan", "ln", "log" -> {
                    val arg = if (eat('(')) { val v = expression(); if (!eat(')')) throw IllegalArgumentException("Missing )"); v } else unary()
                    when (name) {
                        "sqrt" -> sqrt(arg)
                        "sin" -> sin(Math.toRadians(arg))
                        "cos" -> cos(Math.toRadians(arg))
                        "tan" -> tan(Math.toRadians(arg))
                        "ln" -> ln(arg)
                        else -> log10(arg)
                    }
                }
                else -> throw IllegalArgumentException("Unknown function")
            }
        }
        throw IllegalArgumentException("Expected number")
    }
}
