package com.luxecalc.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ExpressionParserTest {
    @Test fun arithmetic() {
        assertEquals(60.0, ExpressionParser("25+35").parse(), 0.000001)
        assertEquals(55.0, ExpressionParser("100-45").parse(), 0.000001)
        assertEquals(144.0, ExpressionParser("12×12").parse(), 0.000001)
        assertEquals(25.0, ExpressionParser("100÷4").parse(), 0.000001)
    }
    @Test fun precedenceAndParentheses() {
        assertEquals(14.0, ExpressionParser("2+3*4").parse(), 0.000001)
        assertEquals(20.0, ExpressionParser("(2+3)*4").parse(), 0.000001)
    }
    @Test(expected = ArithmeticException::class)
    fun divisionByZero() { ExpressionParser("5/0").parse() }
}
