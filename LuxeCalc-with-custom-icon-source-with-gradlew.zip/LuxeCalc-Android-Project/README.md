# LuxeCalc

A premium, offline-first native Android calculator built with Kotlin and Jetpack Compose.

## Features
- iPhone-inspired calculator interface
- Dark and light themes
- Basic arithmetic, percentage, sign toggle and delete
- Scientific functions: sin, cos, tan, square root, ln, log, powers, pi and e
- Calculation history stored locally
- Copy result
- Haptic feedback
- No internet permission or paid service required

## Build
Requirements: JDK 17, Android SDK 35, Gradle 8.9.

```bash
gradle testDebugUnitTest assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Push to `main` or manually run the `LuxeCalc Android APK` workflow from the Actions tab. Download the `LuxeCalc-debug-apk` artifact from the successful run.

## Package
`com.luxecalc.app`

## Important
This is a debug build starter. Before commercial distribution, test on target devices, create a signed release build, verify branding/assets, and review all dependency licenses.


## Custom launcher icon
The launcher icon has been updated using the supplied calculator logo. PNG density variants are included for older Android versions, with adaptive icons for Android 8.0 and newer.

## Build the updated APK on GitHub
1. Extract this project ZIP.
2. Upload/replace the project files in your GitHub repository (the project root is this folder).
3. Open the repository's **Actions** tab.
4. Select **LuxeCalc Android APK** and choose **Run workflow** (or push the updated files to `main`).
5. Open the completed workflow run and download the `LuxeCalc-debug-apk` artifact.

The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.
