@echo off
setlocal
set GRADLE_VERSION=8.9
set BASE_DIR=%~dp0
set CACHE_DIR=%USERPROFILE%\.gradle\bootstrap\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%CACHE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z='%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -Uri $u -OutFile $z; Expand-Archive -LiteralPath $z -DestinationPath '%CACHE_DIR%' -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" -p "%BASE_DIR%" %*
exit /b %ERRORLEVEL%
