LuxeCalc Android Launcher Icon Pack

INSTALL
1. Extract this ZIP on your phone.
2. Copy the folders inside res/ into:
   app/src/main/res/
   Merge with existing folders; do not delete other resources.
3. Open app/src/main/AndroidManifest.xml.
4. Ensure the <application> tag contains:
   android:icon="@mipmap/ic_launcher"
   android:roundIcon="@mipmap/ic_launcher_round"
5. Commit changes and rerun your GitHub Actions APK workflow.

Included:
- mipmap-mdpi: 48x48
- mipmap-hdpi: 72x72
- mipmap-xhdpi: 96x96
- mipmap-xxhdpi: 144x144
- mipmap-xxxhdpi: 192x192
- 512x512 store/listing icon
- 1024x1024 master logo

Do not replace the entire AndroidManifest.xml. Edit only the icon attributes.
